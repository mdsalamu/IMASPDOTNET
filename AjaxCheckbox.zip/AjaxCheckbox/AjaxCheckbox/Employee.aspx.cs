﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace AjaxCheckbox
{
    public partial class Employee : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["sql"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                country();
                ddlstate.Items.Insert(0, new ListItem("-- select state", "0"));
                gridview();
                
            }
        }

        public void country()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("usp_get_country", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            con.Close();
            if(ds.Tables[0].Rows.Count > 0)
            {
                ddlcountry.DataValueField = "cid";
                ddlcountry.DataTextField = "cname";
                ddlcountry.DataSource = ds;
                ddlcountry.DataBind();
                ddlcountry.Items.Insert(0, new ListItem("-- select country", "0"));
            }
        }

        public void state(string stid)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("usp_get_state", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@sid", stid);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlstate.DataValueField = "sid";
                ddlstate.DataTextField = "sname";
                ddlstate.DataSource = ds;
                ddlstate.DataBind();
                ddlstate.Items.Insert(0, new ListItem("-- select state", "0"));
            }
        }

        public void gridview()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("usp_get_employee", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            con.Close();
            if(ds.Tables[0].Rows.Count > 0)
            {
                grd.DataSource = ds;
                grd.DataBind();
            }
            else
            {
                grd.DataSource = null;
                grd.DataBind();
            }
        }

        protected void ddlcountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlcountry.SelectedValue == "0")
            {
                ddlstate.Enabled = false;
                ddlstate.SelectedValue = "0";
            }
            else
            {
                ddlstate.Enabled = true;
                state(ddlcountry.SelectedValue);

            }
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            string HOB = "";
            for (int i = 0; i < chkhobbies.Items.Count; i++ )
            {
                if(chkhobbies.Items[i].Selected==true)
                {
                    HOB += chkhobbies.Items[i].Text + ",";
                }
            }
            HOB = HOB.Trim(',');
                con.Open();
            SqlCommand cmd = new SqlCommand("usp_insert_update_employee", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@empid", btnsave.Text=="Save" ? 0 : ViewState["pp"]);
            cmd.Parameters.AddWithValue("@name", txtname.Text);
            cmd.Parameters.AddWithValue("@country", ddlcountry.SelectedValue);
            cmd.Parameters.AddWithValue("@state", ddlstate.SelectedValue);
            cmd.Parameters.AddWithValue("@dob", txtdob.Text);
            cmd.Parameters.AddWithValue("@hobbies", HOB);
            cmd.Parameters.AddWithValue("@salary", txtsalary.Text);
            cmd.Parameters.AddWithValue("@isactive",chkactive.Checked==true ? 1 : 0 );
            cmd.ExecuteNonQuery();
            con.Close();
            gridview();
        }

        protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "STS")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("usp_isactive_employee", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@empid", e.CommandArgument);
                cmd.ExecuteNonQuery();
                con.Close();
                gridview();
            }
            if(e.CommandName=="EDT")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("usp_edit_employee", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@empid", e.CommandArgument);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                con.Close();
                if(ds.Tables[0].Rows.Count > 0)
                {
                    txtname.Text = ds.Tables[0].Rows[0]["name"].ToString();
                    ddlcountry.SelectedValue = ds.Tables[0].Rows[0]["country"].ToString();
                    ddlstate.Enabled = true;
                    state(ddlcountry.SelectedValue);
                    ddlstate.SelectedValue = ds.Tables[0].Rows[0]["state"].ToString();
                    txtdob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
                    txtsalary.Text = ds.Tables[0].Rows[0]["salary"].ToString();
                    string[] arr = ds.Tables[0].Rows[0]["hobbies"].ToString().Split(',');
                    chkhobbies.ClearSelection();
                    for(int i=0; i<chkhobbies.Items.Count; i++)
                    {
                        for(int j=0; j<arr.Length; j++)
                        {
                            if(chkhobbies.Items[i].Text==arr[j])
                            {
                                chkhobbies.Items[i].Selected = true;
                                break;
                            }
                        }
                    }
                    if (ds.Tables[0].Rows[0]["isactive"].ToString() == "1")
                    {
                        chkactive.Checked = true;

                    }
                    else
                    {
                        chkactive.Checked = false;
                    }

                    btnsave.Text = "Update";
                    ViewState["pp"] = e.CommandArgument;

                }
            }

            else if(e.CommandName=="DLT")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("usp_delete_employee", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@empid", e.CommandArgument);
                cmd.ExecuteNonQuery();
                con.Close();
                gridview();
            }
        }
    }
}